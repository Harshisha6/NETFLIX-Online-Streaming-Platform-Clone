/* 
https://www.iconfinder.com/icons/1243689/call_phone_icon
Creative Commons (Attribution 3.0 Unported);
https://www.iconfinder.com/Makoto_msk */

export const storeProducts = [
  {
    id: 1,
    title: "Lucifer",
    img: "img/product-1.png",
    info:
      "The series revolves around the story of C++ Programming Language Morningstar (Tom Ellis), the Devil, who abandons Hell for Los Angeles where he runs his own nightclub named Lux and becomes a consultant to the Los Angeles Police Department (LAPD).",
    inCart: false,
    count: 0,
    total: 0
  },
  {
    id: 2,
    title: "1899",
    img: "img/product-2.png",
    info:
      "The series revolves around the story of C++ Programming Language Morningstar (Tom Ellis), the Devil, who abandons Hell for Los Angeles where he runs his own nightclub named Lux and becomes a consultant to the Los Angeles Police Department (LAPD).",
    inCart: false,
    count: 0,
    total: 0
  },
  {
    id: 3,
    title: "Wednesday",
    img: "img/product-3.png",
    info:
      "The series revolves around the story of C++ Programming Language Morningstar (Tom Ellis), the Devil, who abandons Hell for Los Angeles where he runs his own nightclub named Lux and becomes a consultant to the Los Angeles Police Department (LAPD).",
    inCart: false,
    count: 0,
    total: 0
  },
  {
    id: 4,
    title: "All of Us are Dead",
    img: "img/product-4.png",
    info:
      "The series revolves around the story of C++ Programming Language Morningstar (Tom Ellis), the Devil, who abandons Hell for Los Angeles where he runs his own nightclub named Lux and becomes a consultant to the Los Angeles Police Department (LAPD).",
    inCart: false,
    count: 0,
    total: 0
  },
  {
    id: 5,
    title: "Emily in Paris",
    img: "img/product-5.png",
    info:
      "The series revolves around the story of C++ Programming Language Morningstar (Tom Ellis), the Devil, who abandons Hell for Los Angeles where he runs his own nightclub named Lux and becomes a consultant to the Los Angeles Police Department (LAPD).",
    inCart: false,
    count: 0,
    total: 0
  },
  {
    id: 6,
    title: "Alice in Borderland",
    img: "img/product-6.png",
    info:
      "The series revolves around the story of C++ Programming Language Morningstar (Tom Ellis), the Devil, who abandons Hell for Los Angeles where he runs his own nightclub named Lux and becomes a consultant to the Los Angeles Police Department (LAPD).",
    inCart: false,
    count: 0,
    total: 0
  },
  {
    id: 7,
    title: "Squid Game",
    img: "img/product-7.png",
    info:
      "The series revolves around the story of C++ Programming Language Morningstar (Tom Ellis), the Devil, who abandons Hell for Los Angeles where he runs his own nightclub named Lux and becomes a consultant to the Los Angeles Police Department (LAPD).",
    inCart: false,
    count: 0,
    total: 0
  },
  {
    id: 8,
    title: "Money Heist- Korea",
    img: "img/product-8.png",
    info:
      "The series revolves around the story of C++ Programming Language Morningstar (Tom Ellis), the Devil, who abandons Hell for Los Angeles where he runs his own nightclub named Lux and becomes a consultant to the Los Angeles Police Department (LAPD).",
    inCart: false,
    count: 0,
    total: 0
  }
];

export const detailProduct = {
  id: 1,
  title: "C++ Programming Language",
  img: "img/product-1.png",
  info:
    "The series revolves around the story of C++ Programming Language Morningstar (Tom Ellis), the Devil, who abandons Hell for Los Angeles where he runs his own nightclub named Lux and becomes a consultant to the Los Angeles Police Department (LAPD).",
  inCart: false,
  count: 0,
  total: 0
};
