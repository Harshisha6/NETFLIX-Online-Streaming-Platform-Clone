import React from 'react';

export default function CartColumns() {
    return (
        <div className="container-fluid text-center d-none d-lg-block">
          <div className="row">
               <div className="col-10 mx-auto col-lg-2">
                   <h5 className="text-white">Movies</h5>  
               </div>
                <div className="col-10 mx-auto col-lg-2">
                    <h5 className="text-white">Title of the Movie</h5>
                </div>
                <div className="col-10 mx-auto col-lg-2">
                    <h5 className="text-white">Remove</h5>
                </div>
          </div>   
        </div>
    )
}
